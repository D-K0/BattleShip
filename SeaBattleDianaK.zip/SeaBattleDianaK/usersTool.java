
/**
 * tools which the user has, an interface
 */
public interface usersTool
{
    void setCompObject(ComputerBoard cBoard); //setts the computer object

    void setShipMap(); //sets the Ship map

    int setHitMap(); //sets the hit map
}
